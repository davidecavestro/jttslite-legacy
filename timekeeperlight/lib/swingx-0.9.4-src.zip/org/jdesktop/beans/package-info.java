/**
 * Contains classes to extend the functionality defined in the
 * {@code java.beans} package.
 */
package org.jdesktop.beans;

