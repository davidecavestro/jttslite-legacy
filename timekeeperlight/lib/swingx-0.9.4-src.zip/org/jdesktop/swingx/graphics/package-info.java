/**
 * Contains graphic utilities and effects for working with images.
 */
package org.jdesktop.swingx.graphics;

